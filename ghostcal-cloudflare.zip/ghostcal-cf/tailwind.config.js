/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  safelist: [
    'gradient-text','glow-pink','glow-cyan','glow-purple',
    'vp-card','vp-window','vp-btn-primary','vp-btn-secondary',
    'vp-input','vp-badge','vp-badge-cyan','vp-badge-purple',
    'vp-skeleton','vp-tab','show-card','grid-bg','scanlines',
    'pulse-glow','flicker','fade-up','font-retro','font-orb','font-pixel',
  ],
  theme: {
    extend: {
      fontFamily: {
        retro:   ['VT323', 'monospace'],
        orb:     ['Orbitron', 'monospace'],
        pixel:   ['"Press Start 2P"', 'monospace'],
        grotesk: ['Space Grotesk', 'sans-serif'],
        sans:    ['Space Grotesk', 'sans-serif'],
      },
      colors: {
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        card:       { DEFAULT: 'hsl(var(--card))', foreground: 'hsl(var(--card-foreground))' },
        popover:    { DEFAULT: 'hsl(var(--popover))', foreground: 'hsl(var(--popover-foreground))' },
        primary:    { DEFAULT: 'hsl(var(--primary))', foreground: 'hsl(var(--primary-foreground))' },
        secondary:  { DEFAULT: 'hsl(var(--secondary))', foreground: 'hsl(var(--secondary-foreground))' },
        muted:      { DEFAULT: 'hsl(var(--muted))', foreground: 'hsl(var(--muted-foreground))' },
        accent:     { DEFAULT: 'hsl(var(--accent))', foreground: 'hsl(var(--accent-foreground))' },
        destructive:{ DEFAULT: 'hsl(var(--destructive))', foreground: 'hsl(var(--destructive-foreground))' },
        border: 'hsl(var(--border))',
        input:  'hsl(var(--input))',
        ring:   'hsl(var(--ring))',
        vp: {
          pink:   '#ff6ec7',
          purple: '#b44fff',
          cyan:   '#00f5ff',
          blue:   '#4d79ff',
          dark:   '#0d0a1a',
          darker: '#07050f',
          card:   '#150f2a',
          border: '#3d2060',
        },
      },
      backgroundImage: {
        'vp-gradient': 'linear-gradient(135deg, #ff6ec7 0%, #b44fff 50%, #00f5ff 100%)',
        'vp-dark-gradient': 'linear-gradient(135deg, #0d0a1a 0%, #1a0a2e 100%)',
      },
      boxShadow: {
        'neon-pink':   '0 0 10px rgba(255,110,199,0.5), 0 0 30px rgba(255,110,199,0.2)',
        'neon-cyan':   '0 0 10px rgba(0,245,255,0.5), 0 0 30px rgba(0,245,255,0.2)',
        'neon-purple': '0 0 10px rgba(180,79,255,0.5), 0 0 30px rgba(180,79,255,0.2)',
        'card-hover':  '0 0 20px rgba(255,110,199,0.3), 0 8px 32px rgba(0,0,0,0.6)',
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up':   'accordion-up 0.2s ease-out',
        'flicker': 'flicker 5s infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'fade-up': 'fade-up 0.5s ease forwards',
      },
      keyframes: {
        'accordion-down': { from: { height: '0' }, to: { height: 'var(--radix-accordion-content-height)' } },
        'accordion-up':   { from: { height: 'var(--radix-accordion-content-height)' }, to: { height: '0' } },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};